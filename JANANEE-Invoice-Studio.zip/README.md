# JANANEE Invoice Studio

Open `dist/index.html` in a modern browser to use the local app. No installation or server is required.

Enter customer and order details, add items, then select **Save invoice** to keep the invoice in this browser. **Saved invoices** reopens earlier invoices. **Print / Save PDF** opens the browser print dialog; choose Save as PDF, A4, no margins, and disable browser headers and footers. Long invoices are scaled to fit one A4 page.

Records use browser local storage, not a shared database. Use **Export backup** regularly and **Restore backup** on another device. Restoring merges saved records by ID. Exporting a backup also includes the current draft; the restore action restores saved invoices only.

The template recreates the supplied PDF's navy and gold palette, hearts, cream corner, footer waves, table structure, and embedded DejaVu fonts. Optional discounts, advance payments, customer details and notes extend the original layout.

Validation: `node --check dist/app.js` and `node check.cjs`.
